package ltd.newbee.mall.service;

public interface NewBeeMallUserCouponRecordService {
}
