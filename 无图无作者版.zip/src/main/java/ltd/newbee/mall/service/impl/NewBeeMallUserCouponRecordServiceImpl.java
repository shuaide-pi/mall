package ltd.newbee.mall.service.impl;

import ltd.newbee.mall.service.NewBeeMallUserCouponRecordService;
import org.springframework.stereotype.Service;

@Service
public class NewBeeMallUserCouponRecordServiceImpl implements NewBeeMallUserCouponRecordService {
}
